package com.example.coladaweb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onSobre(View view){
        Intent intent = new Intent(this, SobreActivity.class);

        startActivity(intent);
    }

    public void onMercado(View view){
        Intent intent = new Intent(this, MercadoActivity.class);

        startActivity(intent);
    }

    public void onEbay(View view) {
        Intent intent = new Intent(this, EbayActivity.class);

        startActivity(intent);
    }

    public void onBuscape(View view) {
        Intent intent = new Intent(this, BuscapeActivity.class);

        startActivity(intent);
    }

    public void onNet(View view) {
        Intent intent = new Intent(this, NetActivity.class );

        startActivity(intent);
    }
}
